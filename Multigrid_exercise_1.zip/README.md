# MultigridPython

- [x] Create basic FEM program
- [x]  Setup demo problem
