# MultigridPython

- [x] Create basic FEM program
- [x] Setup demo problem
- [x] Solve problem with Jacobi and Forward/Backward Gauss Seidel
